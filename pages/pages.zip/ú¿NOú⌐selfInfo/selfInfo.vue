<template>
	<view class="self-info">
		
			
		<view v-if="!load">
			<view class="item">
				<view class="item-left">头像</view>
				<view class="item-right">
					<image :src="imgUrl"></image>
				</view>
			</view>
			<cmd-cell-item title="用户名" :addon="name" />
			<cmd-cell-item title="性别" :addon="sexValue" arrow @click="showSex" />
			<cmd-cell-item title="出生年月" :addon="date" arrow @click="showDate" />
			 <view class="saveForm" @tap="savaForm">
			     保存修改
			 </view>
		</view>
		
		<view class="progress" v-if="load">
			<progress :percent="percent" stroke-width="2" backgroundColor='transparent' />
		</view>
		<w-picker mode="selector" @confirm="changeSex" ref="sex" themeColor="#f00" :defaultVal="defaultSex" :selectList="sexArr"></w-picker>
		<w-picker mode="date" @confirm="changeDate" ref="date" startYear="1970" endYear="2030" themeColor="#f00" :defaultVal="defaulDate"></w-picker>
	</view>
</template>

<script>
	import cmdCellItem from '@/components/cmd-cell-item/cmd-cell-item.vue'
	import wPicker from "@/components/w-picker/w-picker.vue";
	import {getOpenid,setWappUInfo} from '../../http/http.js'
	let that;
	export default {
		components: {
			cmdCellItem,
			wPicker
		},
		data() {
			return {
				load: true,
				percent: 0,
				pageData: {
					time:''
				},
				sexArr: [{
						label: '男',
						value: '1'
					},
					{
						label: '女',
						value: '0'
					}
				],
				name: '',
				country: '',
				province: '',
				city: '',
				imgUrl: '../../static/img/logo.png',
				sexValue: '女',
				sex: '0',
				defaultSex: [0],
				defaulDate: [10, 0, 0],
				date: '1980-01-01'
			}
		},
		onLoad: function() {
			that = this
			that.loading();
			getOpenid().then((res)=>{
				that.name = res.uinfo.name
				that.imgUrl = res.uinfo.imgurl
				that.sex = res.uinfo.sex
				that.sexValue = res.uinfo.sex == 1? '男':'女'
				that.date = res.uinfo.birthday
				console.log(res.uinfo)
				clearInterval(that.pageData.timer);
				that.percent = 90
				that.load = false
			})
		},
		methods: {
			loading() {
				that.percent = 0
				that.load = true
				//----定时器实现进度条加载----
				that.pageData.timer = setInterval(function() {
					if (that.percent < 90) {
						that.percent = that.percent + 5
					}
				}, 60);
			},
			changeSex(e) {
				console.log(e.checkArr)
				that.sex = e.checkArr.value
				that.sexValue = e.checkArr.label
			},
			showSex() {
				this.$refs.sex.show();
			},
			changeDate(e) {
				that.date = e.result
				console.log(e.result)
				// that.sexValue = e.checkArr.label
			},
			showDate() {
				this.$refs.date.show();
			},
			savaForm() {
				setWappUInfo({
					"nickName": that.name,
					"country": that.country,
					"province": that.province,
					"city": that.city,
					"imgUrl": that.imgUrl,
					"sex": that.sex,
					"birthday": that.date
				}).then((res) => {
					console.log(res)
					if (res.ret == 0) {
						console.log(res);
						uni.showToast({
							title: '保存成功',
							icon: 'success',
							duration: 2000
						});
						setTimeout(function() {
							uni.switchTab({
								url: '../my/my',
							})
						}, 2000);
					}
				})

			},
		}
	}
</script>

<style>
	@import url("./selfInfo.css");
</style>
