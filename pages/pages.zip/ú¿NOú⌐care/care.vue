<template>
	<view>

		<view v-for="(activity,index) in activityList" :key="index" style='width:100%;'>
			<!-- 忆梦想 主题活动 -->
			<view class='areaBox' :style='"height:" + Hei'>
				<image :src='activity.url' mode='scaleToFill' :style='"width:100%;height:" + Hei' @load='imgH' @tap='gto'
				 :data-counts='activity.counts' :data-activityId='activity.activityID' :data-urlBg='activity.urlBg[0]?activity.urlBg[0]:""'
				 :data-name='activity.name' />
				<view class='title'>
					{{activity.name}}
					<view class='logoUrl'>
						<image :src='[activity.logoUrl?activity.logoUrl:""]' mode='widthFix' style='width:100%;height:auto;display:block' />
					</view>
					<view class='tabUrl'>
						<image :src='[activity.smallUrl?activity.smallUrl:""]' mode='widthFix' style='width:100%;height:auto;display:block' />
					</view>
				</view>
				<!-- 分享 点赞 收藏  -->
				<view class="bottom-box">

					<view class='btnBoxs'>
						<button class='btnShare button' :data-activityId='activity.activityID' :data-name='activity.name' open-type='share'>
							<image class="image" src='../../static/img/shares.png' />
						</button>
						<view class='btnShare zan'>
							<!--<canvas canvas-id="canvas-{{activity.id}}" style="position:absolute;transform: translateX(-50%);bottom: 0;left: 20%;width: 200rpx;height: 200rpx;" /> -->
							<image @tap='zanClick' :data-activityId='activity.activityID' :data-index='index' class="image" :src='"../../static/img/zan"+ [activity.zan ? "A": ""] + ".png"' />
							<text class="text">{{activity.upCnt}}</text>
						</view>
						<!-- 收藏 -->
						<view class='btnShare' @tap='care' :data-activityId='activity.activityID' :data-index='index' :data-scid="activity.scid">
							<image class="image" src='../../static/img/shoucangA.png' />
						</view>

					</view>
				</view>
			</view>
		</view>


		<!-- 添加加载进度条 -->
		<view class="progress" v-if="load">
			<progress :percent="percent" stroke-width="2" backgroundColor='transparent' />
		</view>
		<view v-if='!isNull' style='width:100%;text-align:center;font-size:30rpx;color:#101010;margin-top:100rpx'>暂无收藏</view>
	</view>
</template>

<script>
	import {
		delComment,
		searchComment,
		gtoZan,
		Lunbo,
		getOpenid,
		shoucangOrZan
	} from '../../http/http.js'
	let that;
	export default {
		data() {
			return {
				load: true,
				isNull: true,
				percent: 0,
				uid: null,
				iconUrls: [], //活动类型图片
				activityList: [],
				totalPage: 0, //总的页面数量
				currentPage: 1, //当前数据显示的页面
				Hei: "", //这是swiper要动态设置的高度属性
				current: 0,
				zanList: [],
				zan: [], //记录点赞的数据 
				pageData: {
					acList: [],
					timer: null
				},
			}
		},
		onLoad() {
			that = this
			that.uid = uni.getStorageSync("userInfos").uinfo.id
			that.loading();
			//获取收藏列表
			that.getLunbo()
			that.initData()
		},
		methods: {
			loading() {
				that.percent = 0
				that.load = true
				//----定时器实现进度条加载----
				that.pageData.timer = setInterval(function() {
					if (that.percent < 90) {
						that.percent = that.percent + 1
					}
				}, 60);
			},
			initData() {
				getOpenid().then(() => {
					shoucangOrZan({ //获取点赞数据
						"type": 6,
						"uid": that.uid,
						"seo": '',
						"which_page": 1,
						"pageSize": 100,
					}).then((res) => {
						that.zanList = res

						that.searchComment()
					})
				})
			},
			searchComment() {
				searchComment({
					"type": 2,
					"uid": uni.getStorageSync("userInfos").uinfo.id,
					"seo": '',
					"which_page": that.currentPage,
					"pageSize": 10,
				}).then((res) => {
					clearInterval(that.pageData.timer);
					that.percent = 90
					that.load = false
					if (res.ret == 0) {
						var list = res.info.list;
						for (var i = 0; i < list.length; i++) {
							var keycode = list[i].ridInfo.keycode
							var scid = list[i].id;
							var activityID = list[i].rid;
							var name = list[i].ridInfo.name;
							var imgList = list[i].ridInfo.gcImgList;
							var url = '';
							var logoUrl = '';
							var smallUrl = '';
							var upCnt = '' //点赞数量
							var zan = false
							for (var k = 0; k < imgList.length; k++) {
								if (imgList[k].type == 3) {
									url = imgList[k].url;
								}
								if (imgList[k].type == 8) {
									if (imgList[k].seqno == 0) {
										logoUrl = imgList[k].url
									}
								}
								upCnt = res.info.list[i].ridInfo.upCnt
							}

							that.zanList.find((item) => {
								if (item.rid == activityID) {
									zan = true
								}
							})

							that.iconUrls.find((item) => {
								if (item.param1 == keycode) {
									smallUrl = item.url
								}
							})
							var listA = {
								'name': name,
								'url': url,
								'scid': scid,
								'activityID': activityID,
								'logoUrl': logoUrl,
								'smallUrl': smallUrl,
								'zan': zan,
								'upCnt': upCnt == 0 ? '' : upCnt,
							};
							that.pageData.acList.push(listA);
						}
						that.activityList = that.activityList.concat(that.pageData.acList)
						that.totalPage = Math.ceil(res.info.pageInfo.total_cnt / 10)
						that.activityList.length == 0 ? that.isNull = false : that.isNull = true

					}
				})
			},
			/**
			 * 获取公共图片
			 */
			getLunbo() {
				Lunbo({
					"type": 10,
					"goodClassId": '',
					"orderDescCol": '',
					"orderIncCol": '',
					"which_page": '',
					"pageSize": '',
					"param": ''
				}).then((res) => {
					var iconArr = []
					if (res.ret == 0) {
						var list = res.info.list;
						for (var i = 0; i < list.length; i++) {
							if (list[i].param == 3) {
								iconArr.push(list[i])
							}
						}
						that.iconUrls = iconArr
					}
				})
			},
			imgH(e) {
				var winWid = uni.getSystemInfoSync().windowWidth; //获取当前屏幕的宽度
				var imgh = e.detail.height; //图片高度
				var imgw = e.detail.width;
				var swiperH = winWid * imgh / imgw + "px";
				that.Hei = swiperH //设置高度
			},

			//取消收藏的操作
			care(e) {
				console.log(e.currentTarget.dataset.scid);
				var scid = e.currentTarget.dataset.scid;
				//执行取消收藏的操作
				delComment({
					'id': scid
				}).then((res) => {

					if (res.ret == 0) {
						that.pageData.acList = that.pageData.acList.filter((item) => {
							if (item.scid != scid) {
								return item;
							}
						})
						that.activityList = that.pageData.acList
						that.activityList.length == 0 ? that.isNull = false : that.isNull = true

						uni.setStorageSync('care', true)
						uni.showToast({
							title: '取消收藏',
						})
					} else {
						uni.showToast({
							title: '取消失败',
						})
					}
				})
			},
			//点赞事件
			zanClick(e) {
				var activityId = e.currentTarget.dataset.activityid;
				var index = e.currentTarget.dataset.index;
				var message = that.activityList;
				let lock = true;
				if (!lock) return;
				lock = false

				for (let i in message) { //遍历列表数据
					if (i == index) { //根据下标找到目标
						var zanState = message[i].zan == false ? 1 : 0;
						gtoZan({
							"goodsClassId": activityId,
							"isUp": zanState,
						}).then((res) => {
							if (res.ret == 0) {
								message[i].zan == false ? message[i].upCnt++ : message[i].upCnt--
								message[i].zan = !message[i].zan
								uni.showToast({
									title: message[i].zan ? '点赞成功' : '取消点赞',
								})
								that.activityList = message
								let zan = that.zan.find((el, index) => {
									return el.rid == activityId
								});
								if (zan) {
									that.zan.forEach((el, index) => {
										if (el.rid == zan.rid) {
											el.isZan = !zan.isZan
										}
									});
								} else {
									that.zan.push({
										rid: activityId,
										isZan: message[i].zan
									})
								}

								uni.setStorageSync('zan', that.zan)
							}
							lock = true
						})
					}
				}

			},
			gto(e) {
				uni.navigateTo({
					url: `../activity/activity?activityId=${e.currentTarget.dataset.activityid}&name=${e.currentTarget.dataset.name}`
				})

			},
		},

		//页面触底操作
		onReachBottom: function() {
			var currentIndex = that.currentPage
			//执行分页 先判断总页数是否大于1 
			if (that.totalPage > 1) {
				//  判断要执行的页面是否是最后一页
				if (currentIndex < that.totalPage) {
					//获取收藏列表
					that.currentIndex = currentIndex + 1
					that.searchComment()


				} else {
					uni.showToast({
						icon: 'none',
						title: '已经是最后一页啦~',
					})
				}
			} else {
				uni.showToast({
					icon: 'none',
					title: '没有更多啦~',
				})
			}
		},
	}
</script>

<style>
	@import url("./care.css");
</style>
