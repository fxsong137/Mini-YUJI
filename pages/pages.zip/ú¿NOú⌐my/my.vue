<template>
	<view>

		<view class="user">
			<view class="user-icon">
				<image :src="userInfos.imgurl"></image>
			</view>
			<view class="user-info">
				<view class='name'>
					<view class="user-name">{{userInfos.name}}</view>
					<view @tap="toSelfInfo">个人信息</view>
				</view>
			</view>
			<uni-icon type="arrowright" size="20" color="#bbb"></uni-icon>
		</view>
		<uni-list>
			<uni-list-item @tap="toCare" title="收藏" thumb="../../../static/img/shoucangA.png"></uni-list-item>
			<uni-list-item @tap="toMyShape" title="我的体型" show-arrow="false"></uni-list-item>
			<uni-list-item @tap="toFeedback" title="功能反馈"></uni-list-item>
			<uni-list-item title="关于羽迹试试"></uni-list-item>
		</uni-list>
	</view>
</template>

<script>
	import uniList from '../../components/uni-ui/uni-list/uni-list.vue'
	import uniListItem from '../../components/uni-ui/uni-list-item/uni-list-item.vue'
	import uniIcon from "@/components/uni-ui/uni-icon/uni-icon.vue"
	import {
		getOpenid
	} from '../../http/http.js'
	let that;
	export default {
		components: {
			uniList,
			uniListItem,
			uniIcon
		},
		data() {
			return {
				userInfos: {}
			}
		},
		onLoad() {
			that = this
			var userInfos = uni.getStorageSync("userInfos").uinfo
			if(!userInfos) {
				getOpenid().then((res)=>{
					console.log(res)
					that.userInfos = res.unifouserInfos
				})
			} else {
				that.userInfos = userInfos
			}
		},
		methods: {
			bindGetUserInfo(e) {
				console.log(e.detail.userInfo)
				wx.setStorage({
					key: 'user',
					data: e.detail.userInfo,
					success: function(res) {
						// wx.navigateTo({
						// 	url: '../selfInfo/selfInfo',
						// })
					}
				})
			},
			toCare() {
				uni.navigateTo({
				    url: '../care/care'
				});
			},
			toFeedback() {
				uni.navigateTo({
				    url: '../feedback/feedback'
				});
			},
			toMyShape() {
				uni.navigateTo({
				    url: '../myShape/myShape'
				});
			},
			toSelfInfo() {
				uni.navigateTo({
				    url: '../selfInfo/selfInfo'
				});
			}
		}
	}
</script>

<style>
	@import url("./my.css");
</style>
