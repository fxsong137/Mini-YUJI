<template>
	<view style='width:100%'>
	   <image src='http://cdn.jnhangqi.cn/shiyiBg.jpg' mode='widthFix' style='width:100%;height:auto'></image>
	</view>
</template>

<script>
</script>

<style>
</style>
