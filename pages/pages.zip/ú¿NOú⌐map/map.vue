<template>
	<view>
		<map style="width: 100%; height: 300px;" :style="'height:' + windowHeight + 'px'" :latitude="latitude" :longitude="longitude" :markers="covers">
		</map>
	</view>
</template>

<script>
	let that;
	export default {
		data() {
			return {
				windowHeight:'',
				latitude: 22.496195,
				longitude: 113.91766,
				covers: [{
					latitude: 22.496195,
					longitude: 113.91766,
					iconPath: '../../static/img/icon1.png',
					callout: {
						content: '我的位置',
						bgColor: '#000',
						textAlign: 'center',
						display: 'ALWAYS',
						color: '#fff'
					}
				}, {
					latitude: 22.496,
					longitude: 113.917,
					iconPath: '../../static/img/icon1A.png',
					callout: {
						content: '商家的位置',
						bgColor: '#000',
						textAlign: 'center',
						display: 'ALWAYS',
						color: '#fff'
					}
				}]
			}
		},
		onLoad() {
			that = this;
			that.windowHeight = uni.getSystemInfoSync().windowHeight;
		}
	}
</script>

<style>
	@import url("./map.css");
</style>
